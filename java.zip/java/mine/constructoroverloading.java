class abc
	{
		int a;
		abc(int x,int y)
			{
				a=2*(x+y);
				
			}
		abc(int x)//this is called constructor overloading it does not depend on return type so no return type written before both abc
		{
			a=x*x;
			
		}
	
	}
class test1
{
	public static void main(String [] args)
		{
			abc a1=new abc(30);
			
			System.out.println(a1.a);
			abc a2=new abc(2,5);
		
		}


}
