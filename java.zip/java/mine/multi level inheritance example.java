 final class a
{
	int m;
	a(int d)
	{
	m=d;
	
	}

}
class b extends a
{
	int n;
	b(int q,int p)
	{
	super(q);
	n=p;
	
	}



}
class c extends b
{	
	int o; 
	c(int x,int y,int z)
	{
		super(x,y);
		o=z;
	
	
	}
	void show()
	{
		System.out.println(m+"\t"+n+"\t"+o);
	
	}

}

class test
{
	public static void main(String args[])
	{
		c s1=new c(10,20,30);
		s1.show();
	
	}


}
