import java.io.*;
class test
{
	public static void main(String args[])throws IOException
	{
	
	
	int c;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	do{
	
		c=br.read();
		System.out.println(c);
	
	}while(c!='q');
	
	}
}
