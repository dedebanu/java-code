class room
	{
		int length;
		int width;
		void getdata(int x,int y)
		{
			length=x;
			width=y;
		}
		void getdata(int c)//in this case we see two method same name called concept overloading
		{
			length=c;
			width=c;
		}
	
	
	}		
class test
	{
		public static void main(String[] args)
		{
			room r1=new room();
			r1 clone();
			r1.getdata(10,20);
			System.out.println(r1.length);
			System.out.println(r1.width);
		
		}
	
	}
