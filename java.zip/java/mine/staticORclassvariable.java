class a
{
	static int count=0;
	a()
	{
		count++;
	}

 
}
class test
{
	public static void main(String[] args)
	{
		a a1=new a();
		System.out.println(a.count);
		a a2=new a();
		
		System.out.println(a.count);
		a a3=new a();
		System.out.println(a.count);
		/*System.out.println(a1.count);
		System.out.println(a2.count);
		System.out.println(a3.count);*/
	}
}
