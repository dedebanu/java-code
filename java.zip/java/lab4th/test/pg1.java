class student
{
	String name;
	int roll,sub1,sub2,sub3,per;
	void ini(String x,int r,int y,int z,int m)
	{
		name=x;
		roll=r;
		sub1=y;
		sub2=z;
		sub3=m;
		
	
	}
	void calper()
	{
		per=(sub1+sub2+sub3)/3;
	
	}
	void d()
	{
		System.out.println("name = "+name+"\nroll="+roll+"a"+sub1+"b"+sub2+"c"+sub3+"percentage"+per+"\n\n\n");
	
	
	
	}
}
class au
{
	public static void main(String args[])
	{
	 student arr[]=new student[10];
	 for(int i=0;i<10;i++)
	 {
	 	arr[i]=new student();
	 
	 }
	 arr[0].ini("a",1,10,20,30);
	 arr[1].ini("b",2,25,20,30);
	 arr[2].ini("c",3,25,24,30);
	 arr[3].ini("d",4,22,27,35);
	 arr[4].ini("e",5,26,21,50);
	 arr[5].ini("f",6,25,21,60);
	 arr[6].ini("g",7,23,20,38);
	 arr[7].ini("b",2,25,20,30);
	 arr[8].ini("b",2,26,23,90);
	 arr[9].ini("b",2,70,24,90);
	 for(int i=0;i<10;i++)
	 {
	 	arr[i].calper();
	 
	 }
	 student temp;
	 if(args[0].equals("sub1"))
	 {
	 	for(int k=0;k<10;k++)
	 	{
	 		for(int l=k+1;l<10;l++)
	 		{
	 			if(arr[l].sub1>arr[k].sub1)
	 			{
	 				temp=arr[k];
	 				arr[k]=arr[l];
	 				arr[l]=temp;
	 			
	 			}
	 		
	 		
	 		}
	 	
	 	}
	 	for(int k=0;k<10;k++)
	 	{
	 	arr[k].d();
	 	
	 	}
	 
	 
	 }
	 else if(args[0].equals("sub2"))
	  {
	 	for(int k=0;k<10;k++)
	 	{
	 		for(int l=k+1;l<10;l++)
	 		{
	 			if(arr[l].sub2>arr[k].sub2)
	 			{
	 				temp=arr[k];
	 				arr[k]=arr[l];
	 				arr[l]=temp;
	 			
	 			}
	 		
	 		
	 		}
	 	
	 	}
	 	for(int k=0;k<10;k++)
	 	{
	 	arr[k].d();
	 	
	 	}
	 
	 
	 }
	 else if(args[0].equals("sub3"))
	  {
	 	for(int k=0;k<10;k++)
	 	{
	 		for(int l=k+1;l<10;l++)
	 		{
	 			if(arr[l].sub3>arr[k].sub3)
	 			{
	 				temp=arr[k];
	 				arr[k]=arr[l];
	 				arr[l]=temp;
	 			
	 			}
	 		
	 		
	 		}
	 	
	 	}
	 	for(int k=0;k<10;k++)
	 	{
	 	arr[k].d();
	 	
	 	}
	 
	 
	 }
	 else
	 {
	 	for(int k=0;k<10;k++)
	 	{
	 		for(int l=k+1;l<10;l++)
	 		{
	 			if(arr[l].per>arr[k].per)
	 			{
	 				temp=arr[k];
	 				arr[k]=arr[l];
	 				arr[l]=temp;
	 			
	 			}
	 		
	 		
	 		}
	 	
	 	}
	 	for(int k=0;k<10;k++)
	 	{
	 	arr[k].d();
	 	
	 	}
	 
	 
	 }
	 
	 
	 
	 }
	
	
	}





