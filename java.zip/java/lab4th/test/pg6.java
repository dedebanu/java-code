interface add
{
	void area();

}
class square implements add
{
	int a=6;
	public void area()
	{
		System.out.println("square"+a*a);
	
	}


}
class circle implements add
{
int r=5;
	public void area()
	{
		System.out.println("square"+3.17*r*r);
	
	}


}
class triangle implements add
{
int b=3,c=7;
	public void area()
	{
		System.out.println("tri"+(b*c)/2);
	
	}


}
class rectangle implements add
{
int p=5,q=1;
	public void area()
	{
		System.out.println("rectangle"+(p+q)*2);
	
	}


}
class test
{
	public static void main(String args[])
	{
		rectangle a=new rectangle();
		a.area();
	
	
	}


}
