class test
{
	public static void main(String args[])
	{
		int array[]={0,1,2,3,4,5};
		try
		{
			System.out.println(array[7]);
		
		}
		finally
		{
			System.out.println("error\n");
		
		}
	
	
	}




}
