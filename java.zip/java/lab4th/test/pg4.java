class acc{

	int accno;
	//String name,bank,branch,type;
	int bal;
	void deposit(int x)
	{
		bal=x;
	
	}
	void with(int y)
	{
		if(bal<y)
		{
			try{
			throw new Exception();
			}
			catch(Exception e){
			System.out.println("error");
			
			}
		}
		else
		{
			bal=bal-y;
		
		}
	
	
	}
	void show()
	{
		System.out.println("acc no="+accno+"balance="+bal);
		
	
	
	
	}
	
}
class test
{
	public static void main(String args[])
	{
	 acc a=new acc();
	 a.deposit(100);
	 a.with(120);
	 a.show();
	
	
	}




}

