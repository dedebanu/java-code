class test
{
	public static void main(String args[])
	{
		int array[]={0,1,2,3,4,5};
		try
		{
			System.out.println(array[7]);
		
		}
		catch(ArithmeticException e)
		{
		System.out.println("in arithmatic");
		
		
		}
		catch(ArrayIndexOutOfBoundsException k)
		{
		System.out.println("in out of bgdf");
		
		}
		finally
		{
			System.out.println("error\n");
		
		}
	
	
	}




}
