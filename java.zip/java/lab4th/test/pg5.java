interface a1
{
	 int a=5;
	void show();

}
interface a2
{

	  int b=10;
	//public void ini(int x,int y);
	
}
class a implements a1,a2
{
	public  void show()
	{
	
	
		System.out.println("a"+a+"b"+b);
	}
	public static void main(String args[])
	{
		a ab=new a();
		//a.ini(1,2);
		ab.show();
	

	}
	
}

