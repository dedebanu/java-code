class a implements Runnable
{
	Thread t;
	a()
	{
		t=new Thread(this);
		t.start();
	
	}
	public void run()
	{
		for(int i=0;i<=10;i++)
		{
			System.out.println("thread a");
		
		}
	
	}



}
class b implements Runnable
{
	Thread t;
	b()
	{
		t=new Thread(this);
		t.start();
	
	}
	public void run()
	{
		for(int i=0;i<=10;i++)
		{
			System.out.println("thread b");
		
		}
	
	}



}
class c implements Runnable
{
	Thread t;
	c()
	{
		t=new Thread(this);
		t.start();
	
	}
	public void run()
	{
		for(int i=0;i<=10;i++)
		{
			System.out.println("thread c");
		
		}
	
	}

}
class test
{
	public static void main(String args[])
	{
		new a();
		new b();
		new c();
	
	
	}

}
