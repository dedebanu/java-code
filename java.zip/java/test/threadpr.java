/*create threee thread */
class a extends Thread
{
	//thread t;
	public void run()
	{
		for(int i=0;i<=10;i++)
		{
		System.out.println("from thread a\n");
		}
	}
	//t.start();

}
class b extends Thread
{
	//thread t;
	public void run()
	{
		for(int i=0;i<=10;i++)
		{
		System.out.println("from thread b\n");
		}
	}
	//t.start();

}
class c extends Thread
{
	//thread t;
	public void run()
	{
		for(int i=0;i<=10;i++)
		{
		System.out.println("from thread c\n");
		}
	}
	//t.start();

}
class test
{
	public static void main(String args[])
	{
		a threada=new a();
		b threadb=new b();
		c threadc=new c();
		threada.setPriority(10);
		threadb.setPriority(4);
		threadc.setPriority(3);
		threada.start();
		threadb.start();
		threadc.start();
	
	
	}


}
