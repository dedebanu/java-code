class a extends Thread
{
	int temp;
	int arr[];

	a(int b[])
	{
		arr=new int[b.length];
		for(int i=0;i<b.length;i++)
		{
			arr[i]=b[i];
			//System.out.println(arr[i]);
		
		}
	
	}
	public void run()
	{
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]>arr[j])
				{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				
				}
			
			}
		
		}
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		
		}
	
	}

}
class c extends Thread
{
	int temp;
	int a[];
	
	c(int b[])
	{
		a=new int[b.length];
		for(int i=0;i<b.length;i++)
		{
			a[i]=b[i];
		
		}
	
	}
	public void run()
	{
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]<a[j])
				{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
				
				}
			
			}
		
		}
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		
		}
	
	}

}
class test
{
	public static void main(String args[])
	{
		int n=args.length;
		int b[]=new int[n];
		for(int i=0;i<n;i++)
		{
			b[i]=Integer.parseInt(args[i]);
			//System.out.println(b[i]);
		
		}
		a ta=new a(b);
		c tc=new c(b);
		ta.start();
		tc.start();
		
	
	
	}
	



}
