import java.util.*;
import java.lang.String;
class Student{
	//static int count=0;
	//int roll,marks;
	//String name;
	/*Student(String str,int x)
	{
		count++;
		roll=count;
		marks=x;
		name=str;
	}*/
	String sub;
	Student(String strn)
	{
		sub=strn;
	}
}
class ArtsStudent extends Student{
	String name;
	int marks;
	ArtsStudent( String st,int x)
	{
		super("arts");
		name=st;
		marks=x;
		//sub="Arts";
	}
	void show()
	{
		System.out.println("Name :"+name+"\nDepartment :"+sub+"\nMarks Obtained:"+marks);
	}
}
class ScienceStudent extends Student{
	String name;
	int marks;
	ScienceStudent(String st,int x)
	{
		super("science");
		//sub="Science";
		name=st;
		marks=x;
	}
	void show()
	{
		System.out.println("Name :"+name+"\nDepartment :"+sub+"\nMarks Obtained :"+marks);
	}
}
class Lolwa{
	public static void main(String args[])
	{
		ArtsStudent s1=new ArtsStudent("A",90);
		ScienceStudent s2=new ScienceStudent("P",89);
		ScienceStudent s3=new ScienceStudent("C",88);
		ArtsStudent s4=new ArtsStudent("Z",97);
		ScienceStudent s5=new ScienceStudent("X",91);
		ArtsStudent s6=new ArtsStudent("M",94);
		
		Vector v=new Vector();
		v.addElement(s1);
		v.addElement(s2);
		v.addElement(s3);
		v.addElement(s4);
		v.addElement(s5);
		v.addElement(s6);
		
		ArtsStudent A[]=new ArtsStudent[10];
		ScienceStudent S[]=new ScienceStudent[10];
		Student stud;
		int i,j,k,l;
		j=0;k=0;l=0;
		//Student St=v.elementAt(i);
		for(i=0;i<v.size();i++)
		{
			stud=(Student)v.elementAt(i);
			if(stud.sub.equals("arts"))
			{
				A[l]=(ArtsStudent)stud;
				l++;
			}	
			else if(stud.sub.equals("science"))
			{
				S[k]=(ScienceStudent)stud;
				k++;
			}
		}
		ArtsStudent tempA;
		ScienceStudent tempS;
		if(args[0].equals("arts")&& args[1].equals("science"))
		{
			//System.out.println("hello");
			for(i=0;i<l;i++)
			{
				for(j=0;j<l-i-1;j++)
				{
					if(A[j].marks>A[j+1].marks)
					{
						tempA=A[j];
						A[j]=A[j+1];
						A[j+1]=tempA;
					}
				}
			}
			for(i=0;i<l;i++)
			{
				A[i].show();
			}
			for(i=0;i<k;i++)
			{
				for(j=0;j<k-i-1;j++)
				{
					if(S[j].marks>S[j+1].marks)
					{
						tempS=S[j];
						S[j]=S[j+1];
						S[j+1]=tempS;
					}
				}
			}
			for(i=0;i<k;i++)
			{
				S[i].show();
			}
		}
		if(args[0].equals("science")&&args[0].equals("arts"))
		{
			for(i=0;i<k;i++)
			{
				for(j=0;j<k-i-1;j++)
				{
					if(S[j].marks>S[j+1].marks)
					{
						tempS=S[j];
						S[j]=S[j+1];
						S[j+1]=tempS;
					}
				}
			}
			for(i=0;i<k;i++)
			{
				S[i].show();
			}
			for(i=0;i<l;i++)
			{
				for(j=0;j<l-i-1;j++)
				{
					if(A[j].marks>A[j+1].marks)
					{
						tempA=A[j];
						A[j]=A[j+1];
						A[j+1]=tempA;
					}
				}
			}
			for(i=0;i<l;i++)
			{
				A[i].show();
			}
		}
		
		
	}
	
}
	
