class abc
	{
		//int a,b;
		int abc(int x,int y)
			{
				return(2*(x+y));
				
			}
		int abc(int x)//this is called constructor overloading it does not depend on return type so no return type written before both abc
		{
			return(x*x);
			
		}
	
	}
class p
{
	public static void main(String [] args)
		{
			abc a1=new abc(30);
			
			System.out.println(a1.a);
		
		}


}
