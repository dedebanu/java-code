class area
{
	public double ar(int l,int m)
	{
	return (2*(l+m));
	
	}
	public double ar(int l)
	{
	return (l*l);
	
	}
	public double ar(float k)
	{
	return (3.14*k*k);
	
	}
	public double ar(float o,float p)
	{
	return ((o*p)/2);
	
	}
	

}
class pg1
{
	public static void main(String args[])
	{
	area a=new area();
	double b,c;
	
	b=a.ar(2,4);
	System.out.println("rectangle\n");
	System.out.println(b);
	b=a.ar(5);
	System.out.println("square");
	System.out.println(b);
	c=a.ar(5.02f);
	System.out.println("circle");
	System.out.println(c);
	c=a.ar(5.02f,6.02f);
	System.out.println("triangle");
	System.out.println(c);
	//return 0;
	
	}



}
