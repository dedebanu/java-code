class account
{
	 float cid=3000114010f,acno=600;
	static float balance=0;
	public void initial(float x)
		{
			balance=x;	
	
		}
	public void deposit(float y)
		{
	
			balance=balance+y;
	
		}
	public void withdraw(float z)
		{
		
			System.out.println(balance);
			balance=balance-z;
			System.out.println("after removal\n");
			System.out.println(balance);
		
		
		}
	public void all()
	{	System.out.println("customer id is");
		System.out.println(cid);
		System.out.println("account no is");
		System.out.println(acno);
		System.out.println("balance is");
		System.out.println(balance);
	
	
	}
	



}
class test
{
	public static void main(String args[])
	{
		account a=new account();
		a.initial(500f);
		System.out.println(a.balance);
		a.deposit(1000f);
		System.out.println(a.balance);
		a.withdraw(100f);
		a.all();
	
	
	
	}




}
