class student
{
	String name="Debayan";
	int roll,submark,smark,tmark;
	char g;
	public void ini(int x,int y,int z)
		{
		
			roll=x;
			submark=y;
			smark=z;
		
		
		}
	public void total()
		{
			tmark=submark+smark;
		
		
		}
	public void dmark()
		{
			System.out.println(tmark);
		
		
		}
	public void grade()
		{
			if(tmark>90)
			{
				System.out.println("A");
			
			}
			else if(tmark<=90&&tmark>80)
			{
				System.out.println("B");
			
			}
			 else if(tmark>70&&tmark<=80)
			{
				System.out.println("c");
			
			}
			else
			{
			
			System.out.println("D");
			}
		
		
		
		}


}
class test 
{
	public static void main(String args[])
	{
	
	student s=new student();
	s.ini(10,50,30);
	s.total();
	s.dmark();
	s.grade();
	
	
	}



}
