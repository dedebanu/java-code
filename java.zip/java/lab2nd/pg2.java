class abc
	{
		int a;
		double b;
		abc(int x,int y)
			{
				a=2*(x+y);
				
			}
		abc(int x)//this is called constructor overloading it does not depend on return type so no return type written before both abc
		{
			a=x*x;
			
		}
		abc(float q)//this is called constructor overloading it does not depend on return type so no return type written before both abc
		{
			b=3.14*q*q;
			
		}
		abc(float q,float r)//this is called constructor overloading it does not depend on return type so no return type written before both abc
		{
			b=(q*r)/2;
			
		}
	
	}
class test1
{
	public static void main(String [] args)
		{
			abc a1=new abc(30);
			System.out.println("rectangle");
			System.out.println(a1.a);
			abc a2=new abc(2,5);
			System.out.println("square");
			System.out.println(a2.a);
			abc a3=new abc(2f);
			System.out.println("circle");
			System.out.println(a3.b);
			abc a4=new abc(2f,5f);
			System.out.println("triangle");
			System.out.println(a4.b);
		
		}


}
