class add
{	
	int a,b;
	public void addx(int x,int y)
	{
		a=x+y;
	
	
	}
	public void addy(int z,int k)
	{
		b=z+k;
		System.out.print(a);
			System.out.print("+");
				System.out.print(b);
					System.out.print("i");
	
	}
	

}
class test
{
	public static void main(String args[])
	{
		add m=new add();
		m.addx(2,5);
		m.addy(4,6);
	
	
	}



}
