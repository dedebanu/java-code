import java.util.*;
import java.lang.String;
class Student{
	
	String sub;
	Student(String strn)
	{
		sub=strn;
	}
}
class ArtsStudent extends Student{
	String name;
	int marks;
	ArtsStudent( String st,int x)
	{
		super("arts");
		name=st;
		marks=x;
		//sub="Arts";
	}
	void show()
	{
		System.out.println("Name :"+name+"\nDepartment :"+sub+"\nMarks Obtained:"+marks);
	}
}
class ScienceStudent extends Student{
	String name;
	int marks;
	ScienceStudent(String st,int x)
	{
		super("science");
		//sub="Science";
		name=st;
		marks=x;
	}
	void show()
	{
		System.out.println("Name :"+name+"\nDepartment :"+sub+"\nMarks Obtained :"+marks);
	}
}
class pg2{
	public static void main(String args[])
	{
		ArtsStudent s1=new ArtsStudent("A",90);
		ScienceStudent s2=new ScienceStudent("P",89);
		ScienceStudent s3=new ScienceStudent("C",88);
		ArtsStudent s4=new ArtsStudent("Z",97);
		ScienceStudent s5=new ScienceStudent("X",91);
		ArtsStudent s6=new ArtsStudent("M",94);
		ArtsStudent s7=new ArtsStudent("b",90);
		ScienceStudent s8=new ScienceStudent("d",89);
		ScienceStudent s9=new ScienceStudent("e",88);
		ArtsStudent s10=new ArtsStudent("f",97);
		ScienceStudent s11=new ScienceStudent("g",91);
		ArtsStudent s12=new ArtsStudent("h",94);
		ArtsStudent s13=new ArtsStudent("A",90);
		ScienceStudent s14=new ScienceStudent("P",89);
		ScienceStudent s15=new ScienceStudent("C",88);
		ArtsStudent s16=new ArtsStudent("Z",97);
		ScienceStudent s17=new ScienceStudent("X",91);
		ArtsStudent s18=new ArtsStudent("M",94);
		ArtsStudent s19=new ArtsStudent("A",90);
		ScienceStudent s20=new ScienceStudent("P",89);
		
		
		Vector v=new Vector();
		v.addElement(s1);
		v.addElement(s2);
		v.addElement(s3);
		v.addElement(s4);
		v.addElement(s5);
		v.addElement(s6);
		v.addElement(s7);
		v.addElement(s8);
		v.addElement(s9);
		v.addElement(s10);
		v.addElement(s11);
		v.addElement(s12);
		v.addElement(s13);
		v.addElement(s14);
		v.addElement(s15);
		v.addElement(s16);
		v.addElement(s17);
		v.addElement(s18);
		v.addElement(s19);
		v.addElement(s20);
		
		ArtsStudent A[]=new ArtsStudent[10];
		ScienceStudent S[]=new ScienceStudent[10];
		Student stud;
		int i,j,k,l;
		j=0;k=0;l=0;
		//Student St=v.elementAt(i);
		for(i=0;i<v.size();i++)
		{
			stud=(Student)v.elementAt(i);
			if(stud.sub.equals("arts"))
			{
				A[l]=(ArtsStudent)stud;
				l++;
			}	
			else if(stud.sub.equals("science"))
			{
				S[k]=(ScienceStudent)stud;
				k++;
			}
		}
		ArtsStudent tempA;
		ScienceStudent tempS;
		if(args[0].equals("arts"))
		{
			//System.out.println("hello");
			for(i=0;i<l;i++)
			{
				for(j=0;j<l-i-1;j++)
				{
					if(A[j].marks>A[j+1].marks)
					{
						tempA=A[j];
						A[j]=A[j+1];
						A[j+1]=tempA;
					}
				}
			}
			for(i=0;i<l;i++)
			{
				A[i].show();
			}
		}
		if(args[0].equals("science"))
		{
			for(i=0;i<k;i++)
			{
				for(j=0;j<k-i-1;j++)
				{
					if(S[j].marks>S[j+1].marks)
					{
						tempS=S[j];
						S[j]=S[j+1];
						S[j+1]=tempS;
					}
				}
			}
			for(i=0;i<k;i++)
			{
				S[i].show();
			}
		}
		
		
	}
	
}
	
