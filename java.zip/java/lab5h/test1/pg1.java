import java.util.*;
class ARTS
{
	String name;
	int id=0;
	int eco;
	int his,geo,per;
	ARTS(String s,int x,int y,int z )
	{
		name=s;
		eco=x;
		his=y;geo=z;
		per=(x+y+z)/3;
	}
	

}
class SCIENCE
{
	String na;
	int id=1;
	int phy,chem,bio,pe;
	 SCIENCE(String s1,int p,int q,int r)
	{
		na=s1;
		phy=p;
		chem=q;
		bio=r;
		pe=(p+q+r)/3;
	
	
	}
}
class test
{
	public static void main(String args[])
	{
	int z=0;
	ARTS m[]=new ARTS[10];
	SCIENCE e[]=new SCIENCE[10];
	Vector  v =new Vector(20);
	ARTS a1=new ARTS("a",20,30,40);
	v.addElement(a1);
	ARTS a2=new ARTS("b",21,31,41);
	v.addElement(a2);
	ARTS a3=new ARTS("c",22,32,40);
	v.addElement(a3);
	ARTS a4=new ARTS("d",25,30,40);
	v.addElement(a4);
	ARTS a5=new ARTS("e",29,33,40);
	v.addElement(a5);
	ARTS a6=new ARTS("f",30,30,40);
	v.addElement(a6);
	ARTS a7=new ARTS("g",20,30,50);
	v.addElement(a7);
	ARTS a8=new ARTS("h",45,30,40);
	v.addElement(a8);
	ARTS a9=new ARTS("i",70,30,40);
	v.addElement(a9);
	ARTS a10=new ARTS("j",80,30,40);
	v.addElement(a10);
	SCIENCE s1=new SCIENCE("k",50,60,70);
	v.addElement(s1);
	SCIENCE s2=new SCIENCE("l",51,60,70);
	v.addElement(s2);
	SCIENCE s3=new SCIENCE("m",57,60,70);
	v.addElement(s3);
	SCIENCE s4=new SCIENCE("n",56,60,70);
	v.addElement(s4);
	v.addElement(a10);
	SCIENCE s5=new SCIENCE("o",50,60,73);
	v.addElement(s5);
	SCIENCE s6=new SCIENCE("p",51,60,76);
	v.addElement(s6);
	SCIENCE s7=new SCIENCE("q",57,60,72);
	v.addElement(s7);
	SCIENCE s8=new SCIENCE("r",56,60,79);
	v.addElement(s8);
	SCIENCE s9=new SCIENCE("s",57,60,75);
	v.addElement(s9);
	SCIENCE s10=new SCIENCE("t",56,60,74);
	v.addElement(s10);
	if(args[0].equals("ARTS"))
	{
		ARTS temp;
		for(int i=0;i<10;i++)
		
		m[i]=(ARTS)v.elementAt(i);
		
		for(int j=0;j<10;j++)
		{
			for(int k=j+1;k<10;k++)
			{
				if(m[j].per>m[k].per)
				{
				temp=m[j];
				m[j]=m[k];
				m[k]=temp;
				
				}
			}
		
		}
		for(int j=0;j<10;j++)
		{
		System.out.println(m[j].name);
		
		}
		//System.out.println(q.id);
	
	}
	else
	{
		SCIENCE tem;
		for(int i=10;i<19;i++)
		e[i-10]=(SCIENCE)v.elementAt(i);
		for(int j=0;j<10;j++)
		{
			for(int k=j+1;k<10;k++)
			{
				if(e[j].pe>e[k].pe)
				{
				tem=e[j];
				e[j]=e[k];
				e[k]=tem;
				
				}
			}
		
		}
		for(int j=0;j<10;j++)
		{
		System.out.println(e[j].na);
		
		}
		//System.out.println(q.id);
	
	}
	
	

}
}






